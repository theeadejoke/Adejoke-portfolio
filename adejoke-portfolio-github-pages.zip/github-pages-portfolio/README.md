# Adejoke’s portfolio — GitHub Pages package

The site is self-contained in `index.html` (the cover image and handwritten type are embedded).

## Publish with GitHub Pages
1. Create a **public** GitHub repository (for example, `adejoke-portfolio`).
2. Choose **Add file → Upload files**, upload `index.html`, and commit it to the `main` branch in the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/(root)`, then save.
5. After GitHub finishes publishing, the site URL will be `https://YOUR-USERNAME.github.io/adejoke-portfolio/` (replace the username and repository name with yours).
